const nodemailer = require('nodemailer');

const mailService = {
    async sendEmail ({emailFrom,emailIto,emailSubject,emailText}){
        const transporter = nodemailer.createTransport({
            host: STMP_HOST,
            port: STMP_PORT,
            auth: {
                user: STMP_USER,
                pass: STMP_PASSWORD,
            }
        });
    },
};
await transporter.sendEmail({
    from : emailFrom,
    to : emailIto,
    subject : emailSubject,
    text : emailText,
});
Object.freeze(mailService);
module.exports = {
    mailService,
};